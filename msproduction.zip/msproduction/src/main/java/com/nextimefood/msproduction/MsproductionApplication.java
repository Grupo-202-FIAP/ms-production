package com.nextimefood.msproduction;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsproductionApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsproductionApplication.class, args);
	}

}
