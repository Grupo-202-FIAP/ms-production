package com.nextimefood.msproduction;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsproductionApplicationTests {

	@Test
	void contextLoads() {
	}

}
